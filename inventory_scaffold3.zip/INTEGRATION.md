# See settings_snippet.py and add urls + app to INSTALLED_APPS.
