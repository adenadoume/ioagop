MEDIA_URL='/media/'
MEDIA_ROOT='media'
STATIC_URL='/static/'
STATIC_ROOT='staticfiles'
