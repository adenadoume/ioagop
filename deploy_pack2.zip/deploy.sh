#!/bin/bash
ansible-playbook -i inventory.ini deploy.yml
