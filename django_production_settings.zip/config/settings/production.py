
# config/settings/production.py
# Production settings for your VPS deploy (Gunicorn + Nginx via Ansible)
# - Reads secrets and config from environment variables (populated by Ansible's .env)
# - Assumes you have a config/settings/base.py. If you don't, create one or copy your current settings to base.py.

from pathlib import Path
import os

# Import all from base; if you don't have base.py, create it and move your common settings there.
try:
    from .base import *  # noqa
except Exception as e:
    raise RuntimeError("Expected config/settings/base.py to exist. Move your common settings there, then import here.") from e

# ---------- Core ----------
DEBUG = False

# Secret key (required). Ansible writes SECRET_KEY in /srv/<project>/shared/.env
SECRET_KEY = os.environ.get("SECRET_KEY")
if not SECRET_KEY:
    raise RuntimeError("SECRET_KEY not found in environment. Ensure Ansible created the .env file.")

# Hosts (comma-separated): example.com,sub.example.com,IP
ALLOWED_HOSTS = [h.strip() for h in os.environ.get("ALLOWED_HOSTS", "").split(",") if h.strip()]

# Build CSRF trusted origins from allowed hosts
def _originify(host: str) -> str:
    host = host.strip()
    if not host:
        return ""
    if host.startswith("http://") or host.startswith("https://"):
        return host
    return f"https://{host}"
CSRF_TRUSTED_ORIGINS = [_originify(h) for h in ALLOWED_HOSTS if h]

# Timezone (optional override)
TIME_ZONE = os.environ.get("TIME_ZONE", "UTC")
USE_TZ = True

# ---------- Database ----------
# DATABASE_URL should look like: postgres://USER:PASSWORD@HOST:PORT/DBNAME
# Ansible sets it to local Postgres by default.
import dj_database_url

DATABASES = {
    "default": dj_database_url.config(
        env="DATABASE_URL",
        conn_max_age=600,
        ssl_require=False  # local Postgres on same host; set True if using managed PG with SSL
    )
}
if not DATABASES["default"]:
    raise RuntimeError("DATABASE_URL not configured. Check your .env from Ansible.")

# ---------- Cache (Redis) ----------
REDIS_URL = os.environ.get("REDIS_URL")
if REDIS_URL:
    CACHES = {
        "default": {
            "BACKEND": "django_redis.cache.RedisCache",
            "LOCATION": REDIS_URL,
            "OPTIONS": {"CLIENT_CLASS": "django_redis.client.DefaultClient"},
            "KEY_PREFIX": os.environ.get("PROJECT_SLUG", "app"),
        }
    }
else:
    # Fallback: in-memory
    CACHES = {
        "default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}
    }

# ---------- Static & Media ----------
# Nginx serves these from /srv/<project>/shared/static and /srv/<project>/shared/media
STATIC_URL = "/static/"
STATIC_ROOT = os.environ.get("STATIC_ROOT", str(Path(BASE_DIR) / "staticfiles"))  # BASE_DIR comes from base.py

MEDIA_URL = "/media/"
MEDIA_ROOT = os.environ.get("MEDIA_ROOT", str(Path(BASE_DIR) / "media"))

# ---------- Security (behind Nginx) ----------
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

FORCE_HTTPS = os.environ.get("FORCE_HTTPS", "1") in ("1", "true", "True")
SESSION_COOKIE_SECURE = FORCE_HTTPS
CSRF_COOKIE_SECURE = FORCE_HTTPS
SECURE_SSL_REDIRECT = FORCE_HTTPS

# ---------- Logging ----------
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {
            "format": "[%(asctime)s] %(levelname)s %(name)s: %(message)s"
        }
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "standard",
        }
    },
    "root": {"handlers": ["console"], "level": os.environ.get("LOG_LEVEL", "INFO")},
}

# ---------- Sentry (optional) ----------
SENTRY_DSN = os.environ.get("SENTRY_DSN")
if SENTRY_DSN:
    import sentry_sdk
    from sentry_sdk.integrations.django import DjangoIntegration
    sentry_sdk.init(
        dsn=SENTRY_DSN,
        integrations=[DjangoIntegration()],
        traces_sample_rate=float(os.environ.get("SENTRY_TRACES", "0.0")),
        send_default_pii=False,
        environment=os.environ.get("SENTRY_ENV", "production"),
    )

# ---------- File upload sizing (adjust as desired) ----------
DATA_UPLOAD_MAX_MEMORY_SIZE = int(os.environ.get("DATA_UPLOAD_MAX_MEMORY_SIZE", str(100 * 1024 * 1024)))  # 100MB
FILE_UPLOAD_MAX_MEMORY_SIZE = int(os.environ.get("FILE_UPLOAD_MAX_MEMORY_SIZE", str(10 * 1024 * 1024)))   # 10MB
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
